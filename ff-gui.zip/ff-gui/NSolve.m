function sol = NSolve(f)
digits(16);

sol = vpasolve(f, [0, 0 + 2 * eps]);

temp = vpasolve(f, [0 + 2 * eps, 1]);
if ~isempty(temp)
    temp = NSolveLow(f, [0 + 2 * eps, 2]);
    sol = [sol; temp];
    if numel(sol) >= 5
        sol = unique(round(sol, 4));
        sol(6:end) = [];
        return;
    end
end

temp = vpasolve(f, [1 + 2 * eps, 10]);
if ~isempty(temp)
    temp = NSolveHigh(f, [1 + 2 * eps, 20]);
    sol = [sol; temp];
    if numel(sol) >= 5
        sol = unique(round(sol, 4));
        sol(6:end) = [];
        return;
    end
end

temp = vpasolve(f, [10 + 2 * eps, 100]);
if ~isempty(temp)
    temp = NSolveHigh(f, [10 + 2 * eps, 200]);
    sol = [sol; temp];
    if numel(sol) >= 5
        sol = unique(round(sol, 4));
        sol(6:end) = [];
        return;
    end
end

temp = vpasolve(f, [100 + 2 * eps, 1000]);
if ~isempty(temp)
    temp = NSolveHigh(f, [100 + 2 * eps, 2000]);
    sol = [sol; temp];
    if numel(sol) >= 5
        sol = unique(round(sol, 4));
        sol(6:end) = [];
        return;
    end
end
end

function sol = NSolveLow(f, range)
sol = sym([]);
for i = range(1):0.1:range(2)
    temp = vpasolve(f, [i, i + 0.1]);
    sol = [sol; temp];
    if numel(sol) >= 5, break; end
end

if numel(sol) >= 3
    for i = range(2):0.1:2 * range(2)
        temp = vpasolve(f, [i, i + 0.1]);
        sol = [sol; temp];
        if numel(sol) >= 5, break; end
    end
end
end

function sol = NSolveHigh(f, range, error)
if nargin < 3, error = 1; end
sol = vpasolve(f, range);
if isempty(sol), return;
else
    lowLimit = sol - error;
    highLimit = sol + error;

    temp = NSolveHigh(f, [range(1), lowLimit], 1);
    if ~isempty(temp), sol = sort([sol; temp]); end

    temp = NSolveHigh(f, [highLimit, range(2)], 1);
    if ~isempty(temp), sol = sort([sol; temp]); end
end
end
