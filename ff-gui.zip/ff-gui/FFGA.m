function varargout = FFGA(varargin)
% FFGA MATLAB code for FFGA.fig
%      FFGA, by itself, creates a new FFGA or raises the existing
%      singleton*.
%
%      H = FFGA returns the handle to a new FFGA or the handle to
%      the existing singleton*.
%
%      FFGA('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FFGA.M with the given input arguments.
%
%      FFGA('Property','Value',...) creates a new FFGA or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FFGA_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FFGA_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FFGA

% Last Modified by GUIDE v2.5 27-Dec-2022 02:55:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name', mfilename, ...
    'gui_Singleton', gui_Singleton, ...
    'gui_OpeningFcn', @FFGA_OpeningFcn, ...
    'gui_OutputFcn', @FFGA_OutputFcn, ...
    'gui_LayoutFcn', [], ...
    'gui_Callback', []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before FFGA is made visible.
function FFGA_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FFGA (see VARARGIN)
% Choose default command line output for FFGA
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes FFGA wait for user response (see UIRESUME)
% uiwait(handles.Application);
movegui(hObject, 'center');
if ~exist('./out', 'dir'), mkdir('./out'); end

% --- Outputs from this function are returned to the command line.
function varargout = FFGA_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --- Executes during object creation, after setting all properties.
function Application_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Application (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
addpath(genpath('fomcon'));

% --- Executes when user attempts to close Application.
function Application_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to Application (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
delete(hObject);
rmpath(genpath('fomcon'));

% --- Executes on selection change in lstPlant.
function lstPlant_Callback(hObject, eventdata, handles)
% hObject    handle to lstPlant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lstPlant contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lstPlant
index = get(hObject, 'Value');

set(handles.txtK, 'Enable', 'on');
set(handles.txtT1, 'Enable', 'on');
set(handles.txtT2, 'Enable', 'on');
set(handles.txtT3, 'Enable', 'on');
set(handles.txtL, 'Enable', 'on');

if index == 1 %% -- Sistem Türü --
    set(handles.txtK, 'Enable', 'inactive');
    set(handles.txtT1, 'Enable', 'inactive');
    set(handles.txtT2, 'Enable', 'inactive');
    set(handles.txtT3, 'Enable', 'inactive');
    set(handles.txtL, 'Enable', 'inactive');

    set(handles.txtK, 'String', '0.0');
    set(handles.txtT1, 'String', '0.0');
    set(handles.txtT2, 'String', '0.0');
    set(handles.txtT3, 'String', '0.0');
    set(handles.txtL, 'String', '0.0');
end

if index == 2 %% Birinci Derece Sistem
    set(handles.txtT2, 'Enable', 'off');
    set(handles.txtT3, 'Enable', 'off');

    set(handles.txtT2, 'String', '0.0');
    set(handles.txtT3, 'String', '0.0');
end

if index == 3 %% İkinci Derece Sistem
    set(handles.txtT3, 'Enable', 'off');

    set(handles.txtT3, 'String', '0.0');
end

% --- Executes during object creation, after setting all properties.
function lstPlant_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lstPlant (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtK_Callback(hObject, eventdata, handles)
% hObject    handle to txtK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtK as text
%        str2double(get(hObject,'String')) returns contents of txtK as a double

% --- Executes during object creation, after setting all properties.
function txtK_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtT1_Callback(hObject, eventdata, handles)
% hObject    handle to txtT1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtT1 as text
%        str2double(get(hObject,'String')) returns contents of txtT1 as a double

% --- Executes during object creation, after setting all properties.
function txtT1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtT1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtT2_Callback(hObject, eventdata, handles)
% hObject    handle to txtT2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtT2 as text
%        str2double(get(hObject,'String')) returns contents of txtT2 as a double


% --- Executes during object creation, after setting all properties.
function txtT2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtT2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtT3_Callback(hObject, eventdata, handles)
% hObject    handle to txtT3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtT3 as text
%        str2double(get(hObject,'String')) returns contents of txtT3 as a double

% --- Executes during object creation, after setting all properties.
function txtT3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtT3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtL_Callback(hObject, eventdata, handles)
% hObject    handle to txtL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtL as text
%        str2double(get(hObject,'String')) returns contents of txtL as a double

% --- Executes during object creation, after setting all properties.
function txtL_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

% --- Executes on selection change in lstController.
function lstController_Callback(hObject, eventdata, handles)
% hObject    handle to lstController (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lstController contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lstController
index = get(hObject, 'Value');

if index == 1 %% -- Kontrolör Türü --
    set(handles.txtKp, 'String', '0.0');
    set(handles.txtKi, 'String', '0.0');
    set(handles.txtKd, 'String', '0.0');
    set(handles.txtLambda, 'String', '0.0');
    set(handles.txtMu, 'String', '0.0');
end

% --- Executes during object creation, after setting all properties.
function lstController_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lstController (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtKp_Callback(hObject, eventdata, handles)
% hObject    handle to txtKp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtKp as text
%        str2double(get(hObject,'String')) returns contents of txtKp as a double

% --- Executes during object creation, after setting all properties.
function txtKp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtKp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtKi_Callback(hObject, eventdata, handles)
% hObject    handle to txtKi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtKi as text
%        str2double(get(hObject,'String')) returns contents of txtKi as a double

% --- Executes during object creation, after setting all properties.
function txtKi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtKi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtKd_Callback(hObject, eventdata, handles)
% hObject    handle to txtKd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtKd as text
%        str2double(get(hObject,'String')) returns contents of txtKd as a double

% --- Executes during object creation, after setting all properties.
function txtKd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtKd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtLambda_Callback(hObject, eventdata, handles)
% hObject    handle to txtLambda (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtLambda as text
%        str2double(get(hObject,'String')) returns contents of txtLambda as a double

% --- Executes during object creation, after setting all properties.
function txtLambda_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtLambda (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtMu_Callback(hObject, eventdata, handles)
% hObject    handle to txtMu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtMu as text
%        str2double(get(hObject,'String')) returns contents of txtMu as a double

% --- Executes during object creation, after setting all properties.
function txtMu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtMu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

% --- Executes on selection change in lstFrequencyFrame.
function lstFrequencyFrame_Callback(hObject, eventdata, handles)
% hObject    handle to lstFrequencyFrame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lstFrequencyFrame contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lstFrequencyFrame
index = get(hObject, 'Value');

set(handles.txtWgc, 'Enable', 'on');
set(handles.txtWpc, 'Enable', 'on');
set(handles.txtPM, 'Enable', 'on');

if index == 1 %% -- Yöntem Türü --
    set(handles.txtWgc, 'Enable', 'inactive');
    set(handles.txtWpc, 'Enable', 'inactive');
    set(handles.txtPM, 'Enable', 'inactive');

    set(handles.txtWgc, 'String', '0.0');
    set(handles.txtWpc, 'String', '0.0');
    set(handles.txtPM, 'String', '0.0');
end

if index == 2 %% Tek Frekans Sınır Değeri
    set(handles.txtWpc, 'Enable', 'off');

    set(handles.txtWpc, 'String', '0.0');
end

% --- Executes during object creation, after setting all properties.
function lstFrequencyFrame_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lstFrequencyFrame (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtWgc_Callback(hObject, eventdata, handles)
% hObject    handle to txtWgc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtWgc as text
%        str2double(get(hObject,'String')) returns contents of txtWgc as a double

% --- Executes during object creation, after setting all properties.
function txtWgc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtWgc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtWpc_Callback(hObject, eventdata, handles)
% hObject    handle to txtWpc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtWpc as text
%        str2double(get(hObject,'String')) returns contents of txtWpc as a double

% --- Executes during object creation, after setting all properties.
function txtWpc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtWpc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

function txtPM_Callback(hObject, eventdata, handles)
% hObject    handle to txtPM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtPM as text
%        str2double(get(hObject,'String')) returns contents of txtPM as a double

% --- Executes during object creation, after setting all properties.
function txtPM_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtPM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
    set(hObject, 'BackgroundColor', 'white');
end

% --- Executes on button press in btnSBL.
function btnSBL_Callback(hObject, eventdata, handles)
% hObject    handle to btnSBL (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc, close(findall(groot, 'Type', 'figure', 'Name', '', 'Tag', ''));
disp('SBL işlemleri başladı...');

vPlant = get(handles.lstPlant, 'Value');
if vPlant == 1, msgbox('Lütfen, Plant Türünü Seçiniz.', 'Uyarı', 'warn'), return; end
items = get(handles.lstPlant, 'String');
sPlant = items{vPlant};

vController = get(handles.lstController, 'Value');
if vController == 1, msgbox('Lütfen, Kontrolör Türünü Seçiniz.', 'Uyarı', 'warn'), return; end
items = get(handles.lstController, 'String');
sController = items{vController};

K = str2double(strrep(get(handles.txtK, 'String'), ',', '.'));
T1 = str2double(strrep(get(handles.txtT1, 'String'), ',', '.'));
T2 = str2double(strrep(get(handles.txtT2, 'String'), ',', '.'));
T3 = str2double(strrep(get(handles.txtT3, 'String'), ',', '.'));
L = str2double(strrep(get(handles.txtL, 'String'), ',', '.'));

SBL(vPlant-1, sController, K, T1, T2, T3, L);
disp('SBL işlemleri tamamlandı...');

% --- Executes on button press in btnSTEP.
function btnSTEP_Callback(hObject, eventdata, handles)
% hObject    handle to btnSTEP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc, close(findall(groot, 'Type', 'figure', 'Name', '', 'Tag', ''));
disp('Step işlemleri başladı...');

vPlant = get(handles.lstPlant, 'Value');
if vPlant == 1, msgbox('Lütfen, Plant Türünü Seçiniz.', 'Uyarı', 'warn'), return; end
items = get(handles.lstPlant, 'String');
sPlant = items{vPlant};

vController = get(handles.lstController, 'Value');
if vController == 1, msgbox('Lütfen, Kontrolör Türünü Seçiniz.', 'Uyarı', 'warn'), return; end
items = get(handles.lstController, 'String');
sController = items{vController};

vFrequencyFrame = get(handles.lstFrequencyFrame, 'Value');
if vFrequencyFrame == 1, msgbox('Lütfen, Yöntem Türünü Seçiniz.', 'Uyarı', 'warn'), return; end
items = get(handles.lstFrequencyFrame, 'String');
sFrequencyFrame = items{vFrequencyFrame};

if vFrequencyFrame == 2 %% Tek Frekans Sınır Değeri
    if startsWith(sController, 'FO')
        msgbox('Kesir Dereceli Kontrolör Türleri için Yöntem Türünü ''Çift Frekans Sınır Değeri'' Seçiniz.', 'Bilgilendirme', 'help');
        return;
    end
end

if vFrequencyFrame == 3 %% Çift Frekans Sınır Değeri
    if startsWith(sController, 'IO')
        msgbox('Tamsayı Dereceli Kontrolör Türleri için Yöntem Türünü ''Tek Frekans Sınır Değeri'' Seçiniz.', 'Bilgilendirme', 'help');
        return;
    end
end

K = str2double(strrep(get(handles.txtK, 'String'), ',', '.'));
T1 = str2double(strrep(get(handles.txtT1, 'String'), ',', '.'));
T2 = str2double(strrep(get(handles.txtT2, 'String'), ',', '.'));
T3 = str2double(strrep(get(handles.txtT3, 'String'), ',', '.'));
L = str2double(strrep(get(handles.txtL, 'String'), ',', '.'));

Wgc = str2double(strrep(get(handles.txtWgc, 'String'), ',', '.'));
Wpc = str2double(strrep(get(handles.txtWpc, 'String'), ',', '.'));
PM = str2double(strrep(get(handles.txtPM, 'String'), ',', '.')) * pi / 180;

[Kp, Ki, Kd, Lambda, Mu] = Step(vPlant-1, sController, sFrequencyFrame, K, T1, T2, T3, L, Wgc, Wpc, PM);

set(handles.txtKp, 'String', Kp);
set(handles.txtKi, 'String', Ki);
set(handles.txtKd, 'String', Kd);
set(handles.txtLambda, 'String', Lambda);
set(handles.txtMu, 'String', Mu);

disp('Step işlemleri tamamlandı...');

% --- Executes on button press in btnBODE.
function btnBODE_Callback(hObject, eventdata, handles)
% hObject    handle to btnBODE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clc, close(findall(groot, 'Type', 'figure', 'Name', '', 'Tag', ''));
disp('Bode işlemleri başladı...');

vPlant = get(handles.lstPlant, 'Value');
if vPlant == 1, msgbox('Lütfen, Plant Türünü Seçiniz.', 'Uyarı', 'warn'), return; end
items = get(handles.lstPlant, 'String');
sPlant = items{vPlant};

vController = get(handles.lstController, 'Value');
if vController == 1, msgbox('Lütfen, Kontrolör Türünü Seçiniz.', 'Uyarı', 'warn'), return; end
items = get(handles.lstController, 'String');
sController = items{vController};

vFrequencyFrame = get(handles.lstFrequencyFrame, 'Value');
if vFrequencyFrame == 1, msgbox('Lütfen, Yöntem Türünü Seçiniz.', 'Uyarı', 'warn'), return; end
items = get(handles.lstFrequencyFrame, 'String');
sFrequencyFrame = items{vFrequencyFrame};

if vFrequencyFrame == 2 %% Tek Frekans Sınır Değeri
    if startsWith(sController, 'FO')
        msgbox('Kesir Dereceli Kontrolör Türleri için Yöntem Türünü ''Çift Frekans Sınır Değeri'' Seçiniz.', 'Bilgilendirme', 'help');
        return;
    end
end

if vFrequencyFrame == 3 %% Çift Frekans Sınır Değeri
    if startsWith(sController, 'IO')
        msgbox('Tamsayı Dereceli Kontrolör Türleri için Yöntem Türünü ''Tek Frekans Sınır Değeri'' Seçiniz.', 'Bilgilendirme', 'help');
        return;
    end
end

K = str2double(strrep(get(handles.txtK, 'String'), ',', '.'));
T1 = str2double(strrep(get(handles.txtT1, 'String'), ',', '.'));
T2 = str2double(strrep(get(handles.txtT2, 'String'), ',', '.'));
T3 = str2double(strrep(get(handles.txtT3, 'String'), ',', '.'));
L = str2double(strrep(get(handles.txtL, 'String'), ',', '.'));

Wgc = str2double(strrep(get(handles.txtWgc, 'String'), ',', '.'));
Wpc = str2double(strrep(get(handles.txtWpc, 'String'), ',', '.'));
PM = str2double(strrep(get(handles.txtPM, 'String'), ',', '.')) * pi / 180;

[Kp, Ki, Kd, Lambda, Mu] = Bode(vPlant-1, sController, sFrequencyFrame, K, T1, T2, T3, L, Wgc, Wpc, PM);

set(handles.txtKp, 'String', Kp);
set(handles.txtKi, 'String', Ki);
set(handles.txtKd, 'String', Kd);
set(handles.txtLambda, 'String', Lambda);
set(handles.txtMu, 'String', Mu);

disp('Bode işlemleri tamamlandı...');

% --- Executes on button press in btnPlantHelp.
function btnHelp_Callback(hObject, eventdata, handles)
% hObject    handle to btnPlantHelp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
web(['file:///', 'html/help.html'])
