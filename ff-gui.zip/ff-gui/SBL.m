function SBL(Plant, Controller, K, T1, T2, T3, L)
filename = ['./out/', datestr(now, 'yyyy-mm-dd_HH-MM'), '.sbl'];
fileID = fopen(filename, 'w');
fprintf(fileID, '--------------------------------> SBL: %d. Dereceden Plant için %s\n', Plant, Controller);
fprintf(fileID, 'K=%.6f, T/T1=%.6f, T2=%.6f, T3=%.6f, L=%.6f\n', K, T1, T2, T3, L);
if endsWith(Controller, 'PI')
    RRB = 0 / K; % Ki = 0 / K
    fprintf(fileID, 'RRB Çizgisi=%.6f -> (Ki = 0 / K)\n\n', RRB);
end
if endsWith(Controller, 'PD')
    RRB = -1 / K; % Kp = -1 / K
    fprintf(fileID, 'RRB Çizgisi=%.6f -> (Kp = -1 / K)\n\n', RRB);
end

if startsWith(Controller, 'IO')
    if endsWith(Controller, 'PI')
        [kp, ki] = eval(sprintf('SBL%d%s(%f, %f, %f, %f, %f);', Plant, Controller, K, T1, T2, T3, L));

        sol = NSolve(kp == RRB);
        fprintf(fileID, ['\tKp için w değerleri:', repmat('%15.6f', 1, numel(sol)), '\n'], sol);

        sol = NSolve(ki == RRB);
        fprintf(fileID, ['\tKi için w değerleri:', repmat('%15.6f', 1, numel(sol)), '\n'], sol);

        PlotSBLIOPI(kp, ki, double(sol(1:2)'), RRB);
    end

    if endsWith(Controller, 'PD')
        [kp, kd] = eval(sprintf('SBL%d%s(%f, %f, %f, %f, %f);', Plant, Controller, K, T1, T2, T3, L));

        sol = NSolve(kd == RRB);
        fprintf(fileID, ['\tKd için w değerleri:', repmat('%15.6f', 1, numel(sol)), '\n'], sol);

        sol = NSolve(kp == RRB);
        fprintf(fileID, ['\tKp için w değerleri:', repmat('%15.6f', 1, numel(sol)), '\n'], sol);

        PlotSBLIOPD(kd, kp, double(sol(1:2)'), RRB);
    end
end

if startsWith(Controller, 'FO')
    for i = 0.25:0.25:1.75
        if endsWith(Controller, 'PI')
            lambda = i;
            fprintf(fileID, 'Lambda=%.6f\n', lambda);
            [kp, ki] = eval(sprintf('SBL%d%s(%f, %f, %f, %f, %f, %f);', Plant, Controller, K, T1, T2, T3, L, lambda));

            sol = NSolve(kp == RRB);
            fprintf(fileID, ['\tKp için w değerleri:', repmat('%15.6f', 1, numel(sol)), '\n'], sol);

            sol = NSolve(ki == RRB);
            fprintf(fileID, ['\tKi için w değerleri:', repmat('%15.6f', 1, numel(sol)), '\n'], sol);

            PlotSBLFOPI(kp, ki, double(sol(1:2)'), lambda, RRB);
        end

        if endsWith(Controller, 'PD')
            mu = i;
            fprintf(fileID, 'Mu=%.6f\n', mu);
            [kp, kd] = eval(sprintf('SBL%d%s(%f, %f, %f, %f, %f, %f);', Plant, Controller, K, T1, T2, T3, L, mu));

            sol = NSolve(kd == RRB);
            fprintf(fileID, ['\tKd için w değerleri:', repmat('%15.6f', 1, numel(sol)), '\n'], sol);

            sol = NSolve(kp == RRB);
            fprintf(fileID, ['\tKp için w değerleri:', repmat('%15.6f', 1, numel(sol)), '\n'], sol);

            PlotSBLFOPD(kd, kp, double(sol(1:2)'), mu, RRB);
        end
    end
end

fclose(fileID);
web(['file:///', filename], '-new');
end

function [kp, ki] = SBL1IOPI(K, T1, T2, T3, L)
syms w
kp = K.^(-1) .* ((-1) .* cos(L .* w) + T1 .* w .* sin(L .* w));
ki = K.^(-1) .* (T1 .* w.^2 .* cos(L .* w) + w .* sin(L .* w));
end

function [kp, ki] = SBL2IOPI(K, T1, T2, T3, L)
syms w
kp = K.^(-1) .* ((-1) .* cos(L .* w) + T1 .* T2 .* w.^2 .* cos(L .* w) + T1 .* w .* sin(L .* w) + T2 .* w .* sin(L .* w));
ki = K.^(-1) .* (T1 .* w.^2 .* cos(L .* w) + T2 .* w.^2 .* cos(L .* w) + w .* sin(L .* w) + (-1) .* T1 .* T2 .* w.^3 .* sin(L .* w));
end

function [kp, ki] = SBL3IOPI(K, T1, T2, T3, L)
syms w
kp = K.^(-1) .* ((-1) .* cos(L .* w) + T1 .* T2 .* w.^2 .* cos(L .* w) + T1 .* T3 .* w.^2 .* cos(L .* w) + T2 .* T3 .* w.^2 .* cos(L .* w) + T1 .* w .* sin(L .* w) + T2 .* w .* sin(L .* w) + T3 .* w .* sin(L .* w) + (-1) .* T1 .* T2 .* T3 .* w.^3 .* sin(L .* w));
ki = K.^(-1) .* (T1 .* w.^2 .* cos(L .* w) + T2 .* w.^2 .* cos(L .* w) + T3 .* w.^2 .* cos(L .* w) + (-1) .* T1 .* T2 .* T3 .* w.^4 .* cos(L .* w) + w .* sin(L .* w) + (-1) .* T1 .* T2 .* w.^3 .* sin(L .* w) + (-1) .* T1 .* T3 .* w.^3 .* sin(L .* w) + (-1) .* T2 .* T3 .* w.^3 .* sin(L .* w));
end

function [kp, ki] = SBL1FOPI(K, T1, T2, T3, L, lambda)
syms w
kp = (-1) .* K.^(-1) .* (cos(L .* w) + T1 .* w .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + (-1) .* T1 .* w .* sin(L .* w) + cot((1/2) .* lambda .* pi) .* sin(L .* w));
ki = K.^(-1) .* w.^lambda .* (cos((1/2) .* lambda .* pi) .* cot((1/2) .* lambda .* pi) + sin((1/2) .* lambda .* pi)) .* (T1 .* w .* cos(L .* w) + sin(L .* w));
end

function [kp, ki] = SBL2FOPI(K, T1, T2, T3, L, lambda)
syms w
kp = (-1) .* K.^(-1) .* (cos(L .* w) + (-1) .* T1 .* T2 .* w.^2 .* cos(L .* w) + T1 .* w .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + T2 .* w .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + (-1) .* T1 .* w .* sin(L .* w) + (-1) .* T2 .* w .* sin(L .* w) + cot((1/2) .* lambda .* pi) .* sin(L .* w) + (-1) .* T1 .* T2 .* w.^2 .* cot((1/2) .* lambda .* pi) .* sin(L .* w));
ki = (-1) .* K.^(-1) .* w.^lambda .* (cos((1/2) .* lambda .* pi) .* cot((1/2) .* lambda .* pi) + sin((1/2) .* lambda .* pi)) .* ((-1) .* T1 .* w .* cos(L .* w) + (-1) .* T2 .* w .* cos(L .* w) + (-1) .* sin(L .* w) + T1 .* T2 .* w.^2 .* sin(L .* w));
end

function [kp, ki] = SBL3FOPI(K, T1, T2, T3, L, lambda)
syms w
kp = (-1) .* K.^(-1) .* (cos(L .* w) + (-1) .* T1 .* T2 .* w.^2 .* cos(L .* w) + (-1) .* T1 .* T3 .* w.^2 .* cos(L .* w) + (-1) .* T2 .* T3 .* w.^2 .* cos(L .* w) + T1 .* w .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + T2 .* w .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + T3 .* w .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + (-1) .* T1 .* T2 .* T3 .* w.^3 .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + (-1) .* T1 .* w .* sin(L .* w) + (-1) .* T2 .* w .* sin(L .* w) + (-1) .* T3 .* w .* sin(L .* w) + T1 .* T2 .* T3 .* w.^3 .* sin(L .* w) + cot((1/2) .* lambda .* pi) .* sin(L .* w) + (-1) .* T1 .* T2 .* w.^2 .* cot((1/2) .* lambda .* pi) .* sin(L .* w) + (-1) .* T1 .* T3 .* w.^2 .* cot((1/2) .* lambda .* pi) .* sin(L .* w) + (-1) .* T2 .* T3 .* w.^2 .* cot((1/2) .* lambda .* pi) .* sin(L .* w));
ki = (-1) .* K.^(-1) .* ((-1) .* T1 .* w.^(1 + lambda) .* cos((1/2) .* lambda .* pi) .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + (-1) .* T2 .* w.^(1 + lambda) .* cos((1/2) .* lambda .* pi) .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + (-1) .* T3 .* w.^(1 + lambda) .* cos((1/2) .* lambda .* pi) .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + T1 .* T2 .* T3 .* w.^(3 + lambda) .* cos((1/2) .* lambda .* pi) .* cos(L .* w) .* cot((1/2) .* lambda .* pi) + (-1) .* T1 .* w.^(1 + lambda) .* cos(L .* w) .* sin((1/2) .* lambda .* pi) + (-1) .* T2 .* w.^(1 + lambda) .* cos(L .* w) .* sin((1/2) .* lambda .* pi) + (-1) .* T3 .* w.^(1 + lambda) .* cos(L .* w) .* sin((1/2) .* lambda .* pi) + T1 .* T2 .* T3 .* w.^(3 + lambda) .* cos(L .* w) .* sin((1/2) .* lambda .* pi) + (-1) .* w.^lambda .* cos((1/2) .* lambda .* pi) .* cot((1/2) .* lambda .* pi) .* sin(L .* w) + T1 .* T2 .* w.^(2 + lambda) .* cos((1/2) .* lambda .* pi) .* cot((1/2) .* lambda .* pi) .* sin(L .* w) + T1 .* T3 .* w.^(2 + lambda) .* cos((1/2) .* lambda .* pi) .* cot((1/2) .* lambda .* pi) .* sin(L .* w) + T2 .* T3 .* w.^(2 + lambda) .* cos((1/2) .* lambda .* pi) .* cot((1/2) .* lambda .* pi) .* sin(L .* w) + (-1) .* w.^lambda .* sin((1/2) .* lambda .* pi) .* sin(L .* w) + T1 .* T2 .* w.^(2 + lambda) .* sin((1/2) .* lambda .* pi) .* sin(L .* w) + T1 .* T3 .* w.^(2 + lambda) .* sin((1/2) .* lambda .* pi) .* sin(L .* w) + T2 .* T3 .* w.^(2 + lambda) .* sin((1/2) .* lambda .* pi) .* sin(L .* w));
end

function [kp, kd] = SBL1IOPD(K, T1, T2, T3, L)
syms w
kp = K.^(-1) .* ((-1) .* cos(L .* w) + T1 .* w .* sin(L .* w));
kd = K.^(-1) .* w.^(-1) .* ((-1) .* T1 .* w .* cos(L .* w) + (-1) .* sin(L .* w));
end

function [kp, kd] = SBL2IOPD(K, T1, T2, T3, L)
syms w
kp = K.^(-1) .* ((-1) .* cos(L .* w) + T1 .* T2 .* w.^2 .* cos(L .* w) + T1 .* w .* sin(L .* w) + T2 .* w .* sin(L .* w));
kd = K.^(-1) .* w.^(-1) .* ((-1) .* T1 .* w .* cos(L .* w) + (-1) .* T2 .* w .* cos(L .* w) + (-1) .* sin(L .* w) + T1 .* T2 .* w.^2 .* sin(L .* w));
end

function [kp, kd] = SBL3IOPD(K, T1, T2, T3, L)
syms w
kp = K.^(-1) .* ((-1) .* cos(L .* w) + T1 .* T2 .* w.^2 .* cos(L .* w) + T1 .* T3 .* w.^2 .* cos(L .* w) + T2 .* T3 .* w.^2 .* cos(L .* w) + T1 .* w .* sin(L .* w) + T2 .* w .* sin(L .* w) + T3 .* w .* sin(L .* w) + (-1) .* T1 .* T2 .* T3 .* w.^3 .* sin(L .* w));
kd = K.^(-1) .* w.^(-1) .* ((-1) .* T1 .* w .* cos(L .* w) + (-1) .* T2 .* w .* cos(L .* w) + (-1) .* T3 .* w .* cos(L .* w) + T1 .* T2 .* T3 .* w.^3 .* cos(L .* w) + (-1) .* sin(L .* w) + T1 .* T2 .* w.^2 .* sin(L .* w) + T1 .* T3 .* w.^2 .* sin(L .* w) + T2 .* T3 .* w.^2 .* sin(L .* w));
end

function [kp, kd] = SBL1FOPD(K, T1, T2, T3, L, mu)
syms w
kp = (-1) .* K.^(-1) .* (cos(L .* w) + (-1) .* T1 .* w .* cos(L .* w) .* cot((1/2) .* mu .* pi) + (-1) .* T1 .* w .* sin(L .* w) + (-1) .* cot((1/2) .* mu .* pi) .* sin(L .* w));
kd = (-1) .* K.^(-1) .* w.^((-1) .* mu) .* csc((1/2).*mu.*pi) .* (T1 .* w .* cos(L .* w) + sin(L .* w));
end

function [kp, kd] = SBL2FOPD(K, T1, T2, T3, L, mu)
syms w
kp = (-1) .* K.^(-1) .* (cos(L .* w) + (-1) .* T1 .* T2 .* w.^2 .* cos(L .* w) + (-1) .* T1 .* w .* cos(L .* w) .* cot((1/2) .* mu .* pi) + (-1) .* T2 .* w .* cos(L .* w) .* cot((1/2) .* mu .* pi) + (-1) .* T1 .* w .* sin(L .* w) + (-1) .* T2 .* w .* sin(L .* w) + (-1) .* cot((1/2) .* mu .* pi) .* sin(L .* w) + T1 .* T2 .* w.^2 .* cot((1/2) .* mu .* pi) .* sin(L .* w));
kd = K.^(-1) .* w.^((-1) .* mu) .* csc((1/2).*mu.*pi) .* ((-1) .* T1 .* w .* cos(L .* w) + (-1) .* T2 .* w .* cos(L .* w) + (-1) .* sin(L .* w) + T1 .* T2 .* w.^2 .* sin(L .* w));
end

function [kp, kd] = SBL3FOPD(K, T1, T2, T3, L, mu)
syms w
kp = (-1) .* K.^(-1) .* (cos(L .* w) + (-1) .* T1 .* T2 .* w.^2 .* cos(L .* w) + (-1) .* T1 .* T3 .* w.^2 .* cos(L .* w) + (-1) .* T2 .* T3 .* w.^2 .* cos(L .* w) + (-1) .* T1 .* w .* cos(L .* w) .* cot((1/2) .* mu .* pi) + (-1) .* T2 .* w .* cos(L .* w) .* cot((1/2) .* mu .* pi) + (-1) .* T3 .* w .* cos(L .* w) .* cot((1/2) .* mu .* pi) + T1 .* T2 .* T3 .* w.^3 .* cos(L .* w) .* cot((1/2) .* mu .* pi) + (-1) .* T1 .* w .* sin(L .* w) + (-1) .* T2 .* w .* sin(L .* w) + (-1) .* T3 .* w .* sin(L .* w) + T1 .* T2 .* T3 .* w.^3 .* sin(L .* w) + (-1) .* cot((1/2) .* mu .* pi) .* sin(L .* w) + T1 .* T2 .* w.^2 .* cot((1/2) .* mu .* pi) .* sin(L .* w) + T1 .* T3 .* w.^2 .* cot((1/2) .* mu .* pi) .* sin(L .* w) + T2 .* T3 .* w.^2 .* cot((1/2) .* mu .* pi) .* sin(L .* w));
kd = K.^(-1) .* w.^((-1) .* mu) .* csc((1/2).*mu.*pi) .* ((-1) .* T1 .* w .* cos(L .* w) + (-1) .* T2 .* w .* cos(L .* w) + (-1) .* T3 .* w .* cos(L .* w) + T1 .* T2 .* T3 .* w.^3 .* cos(L .* w) + (-1) .* sin(L .* w) + T1 .* T2 .* w.^2 .* sin(L .* w) + T1 .* T3 .* w.^2 .* sin(L .* w) + T2 .* T3 .* w.^2 .* sin(L .* w));
end

function PlotSBLIOPI(f1, f2, range, RRB)
figure, hold on
fplot(f1, f2, range, 'b');
yline(RRB, 'g');
legend('SBL Eğrisi', 'RRB Çizgisi', 'Location', 'best');
title(sprintf('w=[%.6f, %.6f] rad/sn', range));
xlabel('Kp');
ylabel('Ki');
XLim = xlim;
XDiff = unique(diff(xticks));
xlim([XLim(1) - XDiff(1), XLim(2) + XDiff(1)]);
YLim = ylim;
YDiff = unique(diff(yticks));
ylim([YLim(1) - YDiff(1), YLim(2) + YDiff(1)]);
hold off, grid on, box on
pause(0.1)
end

function PlotSBLIOPD(f1, f2, range, RRB)
figure, hold on
fplot(f1, f2, range, 'b');
yline(RRB, 'g');
legend('SBL Eğrisi', 'RRB Çizgisi', 'Location', 'best');
title(sprintf('w=[%.6f, %.6f] rad/sn', range));
xlabel('Kd');
ylabel('Kp');
XLim = xlim;
XDiff = unique(diff(xticks));
xlim([XLim(1) - XDiff(1), XLim(2) + XDiff(1)]);
YLim = ylim;
YDiff = unique(diff(yticks));
ylim([YLim(1) - YDiff(1), YLim(2) + YDiff(1)]);
hold off, grid on, box on
pause(0.1)
end

function PlotSBLFOPI(f1, f2, range, lambda, RRB)
figure, hold on
fplot(f1, f2, range, 'b');
yline(RRB, 'g');
legend('SBL Eğrisi', 'RRB Çizgisi', 'Location', 'best');
title(sprintf('Lambda=%.6f, w=[%.6f, %.6f] rad/sn', lambda, range));
xlabel('Kp');
ylabel('Ki');
XLim = xlim;
XDiff = unique(diff(xticks));
xlim([XLim(1) - XDiff(1), XLim(2) + XDiff(1)]);
YLim = ylim;
YDiff = unique(diff(yticks));
ylim([YLim(1) - YDiff(1), YLim(2) + YDiff(1)]);
hold off, grid on, box on
pause(0.1)
end

function PlotSBLFOPD(f1, f2, range, mu, RRB)
figure, hold on
fplot(f1, f2, range, 'b');
yline(RRB, 'g');
legend('SBL Eğrisi', 'RRB Çizgisi', 'Location', 'best');
title(sprintf('Mu=%.6f, w=[%.6f, %.6f] rad/sn', mu, range));
xlabel('Kd');
ylabel('Kp');
XLim = xlim;
XDiff = unique(diff(xticks));
xlim([XLim(1) - XDiff(1), XLim(2) + XDiff(1)]);
YLim = ylim;
YDiff = unique(diff(yticks));
ylim([YLim(1) - YDiff(1), YLim(2) + YDiff(1)]);
hold off, grid on, box on
pause(0.1)
end
