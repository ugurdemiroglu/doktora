function [Kp, Ki, Kd, Lambda, Mu] = Step(Plant, Controller, FrequencyFrame, K, T1, T2, T3, L, Wgc, Wpc, PM)
filename = ['./out/', datestr(now, 'yyyy-mm-dd_HH-MM'), '.step'];
fileID = fopen(filename, 'w');
fprintf(fileID, '--------------------------------> STEP: %d. Dereceden Plant için %s\n', Plant, Controller);
fprintf(fileID, 'K=%.6f, T/T1=%.6f, T2=%.6f, T3=%.6f, L=%.6f\n', K, T1, T2, T3, L);
fprintf(fileID, 'Wc/Wgc=%.6f, Wpc=%.6f, PM=%.6f\n\n', Wgc, Wpc, round(PM * 180 / pi));

if startsWith(FrequencyFrame, 'Tek')
    [Kp, Ki, Kd, Lambda, Mu] = eval(sprintf('StepOdd%d%s(%d, %d, ''%s'', %f, %f, %f, %f, %f, %f, %f);', Plant, Controller, fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, PM));
end

if startsWith(FrequencyFrame, 'Çift')
    [Kp, Ki, Kd, Lambda, Mu] = eval(sprintf('StepEven%d%s(%d, %d, ''%s'', %f, %f, %f, %f, %f, %f, %f, %f);', Plant, Controller, fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, Wpc, PM));
end

fclose(fileID);
web(['file:///', filename], '-new');
end

function [Kp, Ki, Kd, Lambda, Mu] = StepOdd1IOPI(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, PM)
kp1a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
ki1a = K.^(-1) .* Wgc .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kp2a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
ki2a = (-1) .* K.^(-1) .* Wgc .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);

PrintRootIOPI(fileID, kp1a, ki1a, kp2a, ki2a);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveIOPI(kp1a, ki1a, kp2a, ki2a);

G = mtimes(fotf([T1, 1], [1, 0], K, 0, L), fotf(1, 1, [Kp, Ki], [1, 0]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepOdd2IOPI(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, PM)
kp1a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
ki1a = K.^(-1) .* Wgc .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kp2a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
ki2a = (-1) .* K.^(-1) .* Wgc .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);

PrintRootIOPI(fileID, kp1a, ki1a, kp2a, ki2a);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveIOPI(kp1a, ki1a, kp2a, ki2a);

G = mtimes(fotf([T1 * T2, T1 + T2, 1], [2, 1, 0], K, 0, L), fotf(1, 1, [Kp, Ki], [1, 0]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepOdd3IOPI(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, PM)
kp1a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
ki1a = K.^(-1) .* Wgc .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kp2a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
ki2a = (-1) .* K.^(-1) .* Wgc .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);

PrintRootIOPI(fileID, kp1a, ki1a, kp2a, ki2a);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveIOPI(kp1a, ki1a, kp2a, ki2a);

G = mtimes(fotf([T1 * T2 * T3, T1 * T2 + T1 * T3 + T2 * T3, T1 + T2 + T3, 1], [3, 2, 1, 0], K, 0, L), fotf(1, 1, [Kp, Ki], [1, 0]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepEven1FOPI(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, Wpc, PM)
lambda = sym('lambda');
GM1 = ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM+L.*Wgc+atan(T1 .* Wgc)).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* cot((1 / 2) .* lambda .* pi) .* tan(PM + L .* Wgc + atan(T1.*Wgc)) .* (1 + tan(PM+L.*Wgc+atan(T1 .* Wgc)).^2).^(-1 / 2)) .* ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L.*Wpc+atan(T1 .* Wpc)).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* cot((1 / 2) .* lambda .* pi) .* tan(L .* Wpc + atan(T1.*Wpc)) .* (1 + tan(L.*Wpc+atan(T1 .* Wpc)).^2).^(-1 / 2)).^(-1);
GM2 = Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* Wpc.^((-1) .* lambda) .* (1 + T1.^2 .* Wpc.^2).^(-1 / 2) .* cot(L.*Wpc+atan(T1 .* Wpc)) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(1 / 2);

[lambda, DB, DB2, GM] = FindLambda(GM1, GM2);
PlotLambda(GM1, GM2, lambda, DB2);
PrintLambda(fileID, lambda, DB, GM);

kp1a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
ki1a = K.^(-1) .* Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kp2a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
ki2a = (-1) .* K.^(-1) .* Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kp1b = (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2) + (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(T1 .* Wpc)) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2);
ki1b = DB .* K.^(-1) .* Wpc.^lambda .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(T1 .* Wpc)) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2);
kp2b = DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2) + DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(T1 .* Wpc)) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2);
ki2b = (-1) .* DB .* K.^(-1) .* Wpc.^lambda .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(T1 .* Wpc)) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2);

PrintRootFOPI(fileID, kp1a, ki1a, kp2a, ki2a, kp1b, ki1b, kp2b, ki2b);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveFOPI(DB2, kp1a, ki1a, kp2a, ki2a, lambda);

G = mtimes(fotf([T1, 1], [1, 0], K, 0, L), fotf(1, Lambda, [Kp, Ki], [Lambda, 0]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepEven2FOPI(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, Wpc, PM)
lambda = sym('lambda');
GM1 = ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* cot((1 / 2) .* lambda .* pi) .* tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2)) .* ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* cot((1 / 2) .* lambda .* pi) .* tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2)).^(-1);
GM2 = Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* Wpc.^((-1) .* lambda) .* (1 + T1.^2 .* Wpc.^2).^(-1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(-1 / 2) .* cot(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(1 / 2);

[lambda, DB, DB2, GM] = FindLambda(GM1, GM2);
PlotLambda(GM1, GM2, lambda, DB2);
PrintLambda(fileID, lambda, DB, GM);

kp1a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
ki1a = K.^(-1) .* Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kp2a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
ki2a = (-1) .* K.^(-1) .* Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kp1b = (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2) + (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2);
ki1b = DB .* K.^(-1) .* Wpc.^lambda .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2);
kp2b = DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2) + DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2);
ki2b = (-1) .* DB .* K.^(-1) .* Wpc.^lambda .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2);

PrintRootFOPI(fileID, kp1a, ki1a, kp2a, ki2a, kp1b, ki1b, kp2b, ki2b);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveFOPI(DB2, kp1a, ki1a, kp2a, ki2a, lambda);

G = mtimes(fotf([T1 * T2, T1 + T2, 1], [2, 1, 0], K, 0, L), fotf(1, Lambda, [Kp, Ki], [Lambda, 0]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepEven3FOPI(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, Wpc, PM)
lambda = sym('lambda');
GM1 = ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* cot((1 / 2) .* lambda .* pi) .* tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2)) .* ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* cot((1 / 2) .* lambda .* pi) .* tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2)).^(-1);
GM2 = Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* Wpc.^((-1) .* lambda) .* (1 + T1.^2 .* Wpc.^2).^(-1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(-1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(-1 / 2) .* cot(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(1 / 2);

[lambda, DB, DB2, GM] = FindLambda(GM1, GM2);
PlotLambda(GM1, GM2, lambda, DB2);
PrintLambda(fileID, lambda, DB, GM);

kp1a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
ki1a = K.^(-1) .* Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kp2a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
ki2a = (-1) .* K.^(-1) .* Wgc.^lambda .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kp1b = (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2) + (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2);
ki1b = DB .* K.^(-1) .* Wpc.^lambda .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2);
kp2b = DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2) + DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2);
ki2b = (-1) .* DB .* K.^(-1) .* Wpc.^lambda .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*lambda.*pi) .* tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2);

PrintRootFOPI(fileID, kp1a, ki1a, kp2a, ki2a, kp1b, ki1b, kp2b, ki2b);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveFOPI(DB2, kp1a, ki1a, kp2a, ki2a, lambda);

G = mtimes(fotf([T1 * T2 * T3, T1 * T2 + T1 * T3 + T2 * T3, T1 + T2 + T3, 1], [3, 2, 1, 0], K, 0, L), fotf(1, Lambda, [Kp, Ki], [Lambda, 0]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepOdd1IOPD(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, PM)
kp1a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kd1a = K.^(-1) .* Wgc.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kp2a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kd2a = (-1) .* K.^(-1) .* Wgc.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);

PrintRootIOPD(fileID, kp1a, kd1a, kp2a, kd2a);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveIOPD(kp1a, kd1a, kp2a, kd2a);

G = mtimes(fotf([T1, 1], [1, 0], K, 0, L), fotf(1, 0, [Kp, Kd], [0, 1]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepOdd2IOPD(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, PM)
kp1a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kd1a = K.^(-1) .* Wgc.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kp2a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kd2a = (-1) .* K.^(-1) .* Wgc.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);

PrintRootIOPD(fileID, kp1a, kd1a, kp2a, kd2a);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveIOPD(kp1a, kd1a, kp2a, kd2a);

G = mtimes(fotf([T1 * T2, T1 + T2, 1], [2, 1, 0], K, 0, L), fotf(1, 0, [Kp, Kd], [0, 1]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepOdd3IOPD(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, PM)
kp1a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kd1a = K.^(-1) .* Wgc.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kp2a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kd2a = (-1) .* K.^(-1) .* Wgc.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);

PrintRootIOPD(fileID, kp1a, kd1a, kp2a, kd2a);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveIOPD(kp1a, kd1a, kp2a, kd2a);

G = mtimes(fotf([T1 * T2 * T3, T1 * T2 + T1 * T3 + T2 * T3, T1 + T2 + T3, 1], [3, 2, 1, 0], K, 0, L), fotf(1, 0, [Kp, Kd], [0, 1]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepEven1FOPD(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, Wpc, PM)
mu = sym('mu');
GM1 = ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM+L.*Wgc+atan(T1 .* Wgc)).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* cot((1 / 2) .* mu .* pi) .* tan(PM + L .* Wgc + atan(T1.*Wgc)) .* (1 + tan(PM+L.*Wgc+atan(T1 .* Wgc)).^2).^(-1 / 2)) .* ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L.*Wpc+atan(T1 .* Wpc)).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* cot((1 / 2) .* mu .* pi) .* tan(L .* Wpc + atan(T1.*Wpc)) .* (1 + tan(L.*Wpc+atan(T1 .* Wpc)).^2).^(-1 / 2)).^(-1);
GM2 = Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* Wpc.^mu .* (1 + T1.^2 .* Wpc.^2).^(-1 / 2) .* cot(L.*Wpc+atan(T1 .* Wpc)) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(1 / 2);

[mu, DB, DB2, GM] = FindMu(GM1, GM2);
PlotMu(GM1, GM2, mu, DB2);
PrintMu(fileID, mu, DB, GM);

kp1a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kd1a = K.^(-1) .* Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kp2a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kd2a = (-1) .* K.^(-1) .* Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(T1 .* Wgc)) .* (1 + tan(PM + L .* Wgc + atan(T1.*Wgc)).^2).^(-1 / 2);
kp1b = DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2) + (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(L.*Wpc+atan(T1 .* Wpc)) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2);
kd1b = DB .* K.^(-1) .* Wpc.^((-1) .* mu) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(L.*Wpc+atan(T1 .* Wpc)) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2);
kp2b = (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2) + DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(L.*Wpc+atan(T1 .* Wpc)) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2);
kd2b = (-1) .* DB .* K.^(-1) .* Wpc.^((-1) .* mu) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(L.*Wpc+atan(T1 .* Wpc)) .* (1 + tan(L .* Wpc + atan(T1.*Wpc)).^2).^(-1 / 2);

PrintRootFOPD(fileID, kp1a, kd1a, kp2a, kd2a, kp1b, kd1b, kp2b, kd2b);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveFOPD(DB2, kp1a, kd1a, kp2a, kd2a, mu);

G = mtimes(fotf([T1, 1], [1, 0], K, 0, L), fotf(1, 0, [Kp, Kd], [0, Mu]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepEven2FOPD(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, Wpc, PM)
mu = sym('mu');
GM1 = ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* cot((1 / 2) .* mu .* pi) .* tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2)) .* ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* cot((1 / 2) .* mu .* pi) .* tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2)).^(-1);
GM2 = Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* Wpc.^mu .* (1 + T1.^2 .* Wpc.^2).^(-1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(-1 / 2) .* cot(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(1 / 2);

[mu, DB, DB2, GM] = FindMu(GM1, GM2);
PlotMu(GM1, GM2, mu, DB2);
PrintMu(fileID, mu, DB, GM);

kp1a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kd1a = K.^(-1) .* Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kp2a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kd2a = (-1) .* K.^(-1) .* Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(K .* (T1 + T2) .* Wgc .* (K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))) .* (1 + tan(PM + L .* Wgc + atan(K.*(T1 + T2).*Wgc.*(K + (-1) .* K .* T1 .* T2 .* Wgc.^2).^(-1))).^2).^(-1 / 2);
kp1b = DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2) + (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2);
kd1b = DB .* K.^(-1) .* Wpc.^((-1) .* mu) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2);
kp2b = (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2) + DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2);
kd2b = (-1) .* DB .* K.^(-1) .* Wpc.^((-1) .* mu) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(L.*Wpc+atan(K .* (T1 + T2) .* Wpc .* (K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))) .* (1 + tan(L .* Wpc + atan(K.*(T1 + T2).*Wpc.*(K + (-1) .* K .* T1 .* T2 .* Wpc.^2).^(-1))).^2).^(-1 / 2);

PrintRootFOPD(fileID, kp1a, kd1a, kp2a, kd2a, kp1b, kd1b, kp2b, kd2b);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveFOPD(DB2, kp1a, kd1a, kp2a, kd2a, mu);

G = mtimes(fotf([T1 * T2, T1 + T2, 1], [2, 1, 0], K, 0, L), fotf(1, 0, [Kp, Kd], [0, Mu]));
PlotStep(G, Plant, Controller)
end

function [Kp, Ki, Kd, Lambda, Mu] = StepEven3FOPD(fileID, Plant, Controller, K, T1, T2, T3, L, Wgc, Wpc, PM)
mu = sym('mu');
GM1 = ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* cot((1 / 2) .* mu .* pi) .* tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2)) .* ((-1) .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* cot((1 / 2) .* mu .* pi) .* tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2)).^(-1);
GM2 = Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* Wpc.^mu .* (1 + T1.^2 .* Wpc.^2).^(-1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(-1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(-1 / 2) .* cot(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(1 / 2);

[mu, DB, DB2, GM] = FindMu(GM1, GM2);
PlotMu(GM1, GM2, mu, DB2);
PrintMu(fileID, mu, DB, GM);

kp1a = K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2) + (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kd1a = K.^(-1) .* Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kp2a = (-1) .* K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2) + K.^(-1) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kd2a = (-1) .* K.^(-1) .* Wgc.^((-1) .* mu) .* (1 + T1.^2 .* Wgc.^2).^(1 / 2) .* (1 + T2.^2 .* Wgc.^2).^(1 / 2) .* (1 + T3.^2 .* Wgc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(PM+L.*Wgc+atan(Wgc .* ((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))) .* (1 + tan(PM + L .* Wgc + atan(Wgc.*((-1) + T2 .* T3 .* Wgc.^2 + T1 .* (T2 + T3) .* Wgc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wgc.^2)))).^2).^(-1 / 2);
kp1b = DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2) + (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2);
kd1b = DB .* K.^(-1) .* Wpc.^((-1) .* mu) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2);
kp2b = (-1) .* DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2) + DB .* K.^(-1) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* cot((1/2).*mu.*pi) .* tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2);
kd2b = (-1) .* DB .* K.^(-1) .* Wpc.^((-1) .* mu) .* (1 + T1.^2 .* Wpc.^2).^(1 / 2) .* (1 + T2.^2 .* Wpc.^2).^(1 / 2) .* (1 + T3.^2 .* Wpc.^2).^(1 / 2) .* csc((1/2).*mu.*pi) .* tan(L.*Wpc+atan(Wpc .* ((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1) .* ((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))) .* (1 + tan(L .* Wpc + atan(Wpc.*((-1) + T2 .* T3 .* Wpc.^2 + T1 .* (T2 + T3) .* Wpc.^2).^(-1).*((-1) .* T2 + (-1) .* T3 + T1 .* ((-1) + T2 .* T3 .* Wpc.^2)))).^2).^(-1 / 2);

PrintRootFOPD(fileID, kp1a, kd1a, kp2a, kd2a, kp1b, kd1b, kp2b, kd2b);
[Kp, Ki, Kd, Lambda, Mu] = ReturnSolveFOPD(DB2, kp1a, kd1a, kp2a, kd2a, mu);

G = mtimes(fotf([T1 * T2 * T3, T1 * T2 + T1 * T3 + T2 * T3, T1 + T2 + T3, 1], [3, 2, 1, 0], K, 0, L), fotf(1, 0, [Kp, Kd], [0, Mu]));
PlotStep(G, Plant, Controller)
end

function [lambda, DB, DB2, GM] = FindLambda(GM1, GM2)
digits(16);
sol = vpasolve(GM1 == GM2, [0 + 2 * eps, 2 - 2 * eps]);
lambda = double(sol);
DB1 = double(subs(GM1, lambda));
DB2 = double(subs(GM2, lambda));
DB = abs(DB1);
GM = 20 * log10(DB);
end

function [mu, DB, DB2, GM] = FindMu(GM1, GM2)
digits(16);
sol = vpasolve(GM1 == GM2, [0 + 2 * eps, 2 - 2 * eps]);
mu = double(sol);
DB1 = double(subs(GM1, mu));
DB2 = double(subs(GM2, mu));
DB = abs(DB1);
GM = 20 * log10(DB);
end

function PlotLambda(GM1, GM2, lambda, DB2)
figure, hold on
fplot(GM1, [0, 2], 'b');
fplot(GM2, [0, 2], 'r');
plot(lambda, DB2, 'Marker', 'x', 'LineStyle', 'none', 'Color', 'k', 'MarkerSize', 6);
legend('Wgc Frekans Değerindeki GM Denklemi', 'Wpc Frekans Değerindeki GM Denklemi', sprintf('Lambda=%.6f', lambda), 'Location', 'best');
title('GM Denklemlerinin Kesişim Noktası');
xlabel('Lambda');
ylabel('10^{GM/20}');
hold off, grid on, box on
end

function PlotMu(GM1, GM2, mu, DB2)
figure, hold on
fplot(GM1, [0, 2], 'b');
fplot(GM2, [0, 2], 'r');
plot(mu, DB2, 'Marker', 'x', 'LineStyle', 'none', 'Color', 'k', 'MarkerSize', 6);
legend('Wgc Frekans Değerindeki GM Denklemi', 'Wpc Frekans Değerindeki GM Denklemi', sprintf('Mu=%.6f', mu), 'Location', 'best');
title('GM Denklemlerinin Kesişim Noktası');
xlabel('Mu');
ylabel('10^{GM/20}');
hold off, grid on, box on
end

function PrintLambda(fileID, lambda, DB, GM)
fprintf(fileID, 'GM Denklemlerinin Kesişim Noktası:\n');
fprintf(fileID, 'Lambda=%.6f\n', lambda);
fprintf(fileID, 'DB=%.6f -> (DB = 10^(GM/20))\n', DB);
fprintf(fileID, 'GM=%.6f desibel -> (GM = 20*log10(DB))\n\n', GM);
end

function PrintMu(fileID, mu, DB, GM)
fprintf(fileID, 'GM Denklemlerinin Kesişim Noktası:\n');
fprintf(fileID, 'Mu=%.6f\n', mu);
fprintf(fileID, 'DB=%.6f -> (DB = 10^(GM/20))\n', DB);
fprintf(fileID, 'GM=%.6f desibel -> (GM = 20*log10(DB))\n\n', GM);
end

function PrintRootIOPI(fileID, kp1a, ki1a, kp2a, ki2a)
fprintf(fileID, 'Eşlenik Kökler:\n');
fprintf(fileID, 'Wc/Wgc Frekans Değerindeki:\n');
fprintf(fileID, '\t1) kp=%.6f ki=%.6f\n', kp1a, ki1a);
fprintf(fileID, '\t2) kp=%.6f ki=%.6f\n', kp2a, ki2a);
end

function PrintRootIOPD(fileID, kp1a, kd1a, kp2a, kd2a)
fprintf(fileID, 'Eşlenik Kökler:\n');
fprintf(fileID, 'Wc/Wgc Frekans Değerindeki:\n');
fprintf(fileID, '\t1) kp=%.6f kd=%.6f\n', kp1a, kd1a);
fprintf(fileID, '\t2) kp=%.6f kd=%.6f\n', kp2a, kd2a);
end

function PrintRootFOPI(fileID, kp1a, ki1a, kp2a, ki2a, kp1b, ki1b, kp2b, ki2b)
fprintf(fileID, 'Eşlenik Kökler:\n');
fprintf(fileID, 'Wgc Frekans Değerindeki:\n');
fprintf(fileID, '\t1) kp=%.6f ki=%.6f\n', kp1a, ki1a);
fprintf(fileID, '\t2) kp=%.6f ki=%.6f\n', kp2a, ki2a);
fprintf(fileID, 'Wpc Frekans Değerindeki:\n');
fprintf(fileID, '\t3) kp=%.6f ki=%.6f\n', kp1b, ki1b);
fprintf(fileID, '\t4) kp=%.6f ki=%.6f\n', kp2b, ki2b);
end

function PrintRootFOPD(fileID, kp1a, kd1a, kp2a, kd2a, kp1b, kd1b, kp2b, kd2b)
fprintf(fileID, 'Eşlenik Kökler:\n');
fprintf(fileID, 'Wgc Frekans Değerindeki:\n');
fprintf(fileID, '\t1) kp=%.6f kd=%.6f\n', kp1a, kd1a);
fprintf(fileID, '\t2) kp=%.6f kd=%.6f\n', kp2a, kd2a);
fprintf(fileID, 'Wpc Frekans Değerindeki:\n');
fprintf(fileID, '\t3) kp=%.6f kd=%.6f\n', kp1b, kd1b);
fprintf(fileID, '\t4) kp=%.6f kd=%.6f\n', kp2b, kd2b);
end

function [Kp, Ki, Kd, Lambda, Mu] = ReturnSolveIOPI(kp1a, ki1a, kp2a, ki2a)
if kp2a > 0
    Kp = kp1a;
    Ki = ki1a;
else
    Kp = kp2a;
    Ki = ki2a;
end
Kd = 0;
Lambda = 1;
Mu = 0;
end

function [Kp, Ki, Kd, Lambda, Mu] = ReturnSolveIOPD(kp1a, kd1a, kp2a, kd2a)
if kp2a < 0
    Kp = kp1a;
    Kd = kd1a;
else
    Kp = kp2a;
    Kd = kd2a;
end
Ki = 0;
Lambda = 0;
Mu = 1;
end

function [Kp, Ki, Kd, Lambda, Mu] = ReturnSolveFOPI(DB2, kp1a, ki1a, kp2a, ki2a, lambda)
if DB2 < 0
    Kp = kp1a;
    Ki = ki1a;
else
    Kp = kp2a;
    Ki = ki2a;
end
Kd = 0;
Lambda = lambda;
Mu = 0;
end

function [Kp, Ki, Kd, Lambda, Mu] = ReturnSolveFOPD(DB2, kp1a, kd1a, kp2a, kd2a, mu)
if DB2 < 0
    Kp = kp1a;
    Kd = kd1a;
else
    Kp = kp2a;
    Kd = kd2a;
end
Ki = 0;
Lambda = 0;
Mu = mu;
end

function PlotStep(G, Plant, Controller)
figure, hold on
step(feedback(G, 1))
legend(sprintf('%d. Dereceden Plant\n%s Kontrolör', Plant, Controller));
title('Birim Basamak Cevabı');
xlabel('Zaman (saniye)');
ylabel('Genlik');
hold off, grid on, box on
end
