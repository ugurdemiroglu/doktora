clc, clear;
close all, fclose all;

run('./FFGA.m');
