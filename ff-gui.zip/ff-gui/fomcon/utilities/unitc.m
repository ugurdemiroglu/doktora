function rec_obj = unitc()
%UNITC Draws a unit circle on the current plot
    rec_obj = rectangle('Position',[-1,-1,2,2],'Curvature',[1,1]);
end

