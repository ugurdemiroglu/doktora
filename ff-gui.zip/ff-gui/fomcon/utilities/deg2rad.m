function rad = deg2rad(deg)
% DEG2RAD Convert degrees to radians.
	rad = (pi/180).*deg;
end